# SecureCorp — Suite de retos web (estilo Juice Shop)

Una única aplicación web con temática de "plataforma de seguridad en la nube"
que integra **4 retos de seguridad independientes**, mezclados de forma homogénea
como si fueran funciones reales del producto. Cada módulo tiene **su propia flag**.

> ⚠️ **Aviso:** este proyecto es **deliberadamente vulnerable**, con fines
> educativos (CTF / formación en seguridad). No lo despliegues en una red no
> confiable ni en producción. Ejecútalo en local o en un entorno aislado.

## Retos

| # | Módulo (sección)          | Vulnerabilidad                         |
|---|---------------------------|----------------------------------------|
| 1 | Portal de empleados `#portal`   | Manipulación de cookies (`role`)          |
| 2 | Centro de documentación `#vault`| LFI / Path Traversal (`?doc=`)            |
| 3 | Compositor de alertas `#alerts` | SSTI (Jinja2) con bypass de WAF           |
| 4 | Desbloqueo de admin `#unlock`   | Contraseña oculta en el HTML              |

## Ejecución

### Con Python

```bash
cd securecorp
pip install -r requirements.txt
python app.py
```

Las flags reales se leen de variables de entorno. En local, sin definirlas,
verás flags de tipo `flag{PLACEHOLDER_...}` (suficiente para probar los
mecanismos). Para probar con valores reales:

```bash
cd securecorp
FLAG_COOKIE='flag{...}' FLAG_LFI='flag{...}' FLAG_SSTI='flag{...}' \
FLAG_UNLOCK='flag{...}' HIDDEN_PASSWORD='...' python app.py
```

### Con Docker

```bash
cd securecorp
docker build -t securecorp .
docker run -p 8000:5000 --env-file ../secrets.env securecorp
```

La app escucha en el puerto de `$PORT` (por defecto **5000**). En macOS el 5000
suele estar ocupado por AirPlay, por eso el ejemplo mapea **8000 → 5000**. Abre
luego `http://localhost:8000`.

## Flags y secretos

**Ninguna flag ni contraseña está en el código.** Se inyectan por entorno:
`FLAG_COOKIE`, `FLAG_LFI`, `FLAG_SSTI`, `FLAG_UNLOCK`, `HIDDEN_PASSWORD`.

- En local están de ejemplo en `secrets.env` (ignorado por git).
- En producción se configuran en el panel del proveedor (ver `DEPLOY-RENDER.md`).
- Al arrancar, la app escribe los ficheros de flag desde el entorno y luego
  **borra los secretos del proceso** para que no se filtren por el propio reto.

## Despliegue

Para publicarlo en Render y pasar la URL a los alumnos, sigue
[`DEPLOY-RENDER.md`](DEPLOY-RENDER.md).

## Nota para el operador

`solution.md` (soluciones y flags, en `.gitignore`) se mantiene solo en tu copia
local. `challenge.md` contiene el enunciado y pistas, **sin** las flags.
