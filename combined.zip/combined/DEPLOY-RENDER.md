# Despliegue en Render

La app se sirve como **Docker Web Service**. Los secretos (flags y contraseña)
**no están en el repo**: se inyectan como *Environment Variables* en Render.

## 1. Sube el repo a GitHub (privado recomendado)

Ver `README.md`. **Haz el repositorio privado**: aunque las flags no estén en el
código, si los alumnos leen el fuente conocen los mecanismos de cada reto.

## 2. Crea el servicio en Render

1. Render → **New** → **Web Service** → conecta tu repo de GitHub.
2. **Root Directory:** `securecorp`
3. **Runtime / Environment:** `Docker` (usa el `Dockerfile`).
4. Render detecta el puerto por la variable `$PORT` (la app ya la respeta).
   No hace falta configurar puerto manualmente.

## 3. Variables de entorno (¡aquí van las flags!)

En **Environment → Add Environment Variable**, añade una por una las de tu
fichero local `secrets.env` (que NO está en git):

| Key | Ejemplo de valor |
|-----|------------------|
| `FLAG_COOKIE` | `flag{...}` |
| `FLAG_LFI` | `flag{...}` |
| `FLAG_SSTI` | `flag{...}` |
| `FLAG_UNLOCK` | `flag{...}` |
| `HIDDEN_PASSWORD` | `mnt-...` |

> Márcalas como *secret*. Si más adelante quieres cambiar una flag, edítala aquí
> y haz *Manual Deploy → Clear build cache & deploy* (o solo *restart*): la app
> las relee en cada arranque.

## 4. Despliega y comparte la URL

Render te da una URL `https://<tu-servicio>.onrender.com`. Ese es el enlace para
los alumnos (no necesitan el repo).

## Por qué es difícil hacer trampas

- **Ninguna flag está en el código ni en ficheros del repo.** Solo hay
  placeholders `flag{PLACEHOLDER_...}`. Leer el fuente no da ninguna flag real.
- Al arrancar, la app **escribe** los ficheros de flag desde las env vars y
  **borra los secretos del entorno del proceso**, así que un LFI a
  `/proc/self/environ` (o leer `os.environ`) no los revela.
- Los `.md` con pistas/soluciones se excluyen de la imagen Docker
  (`.dockerignore`), así que **no** se pueden leer con el LFI del reto.
- `solution.md` y `secrets.env` están en `.gitignore`: nunca se suben.

### Limitación honesta (aislamiento)

El reto **SSTI es ejecución de código** (RCE) dentro del contenedor: quien lo
resuelve puede, en teoría, leer los ficheros de flag de los otros retos basados
en fichero (LFI/SSTI). Del mismo modo, el LFI puede leer el `flag.txt` del SSTI.
Las flags de **cookie** y **desbloqueo** NO están en disco (solo en memoria del
proceso), así que el LFI no las alcanza. Si necesitas aislamiento total entre
retos, despliega cada módulo en un servicio/contenedor separado.
