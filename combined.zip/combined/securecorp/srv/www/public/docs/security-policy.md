# Política de seguridad

- Toda credencial de servicio debe rotarse cada 90 días.
- Los secretos NUNCA se guardan en el repositorio público de documentación.
- El acceso al panel de administración requiere la clave de mantenimiento.
- Reporta incidentes a security@securecorp.example.

## Almacenamiento y copias de seguridad

El visor solo debería servir ficheros `.md` desde el directorio público
`srv/www/public/docs/`. Cualquier otra ruta es un fallo de configuración.

Las copias de seguridad y los volcados internos de operaciones se guardan
**fuera** del árbol público, en `srv/private/` (no accesible desde el visor).
Si un fichero privado aparece en el visor, repórtalo de inmediato: significa que
el saneamiento de rutas ha fallado.
