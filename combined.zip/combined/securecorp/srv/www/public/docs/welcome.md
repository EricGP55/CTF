# Bienvenido a SecureCorp Vault

Este es el centro de documentación interno. Aquí encontrarás guías rápidas,
políticas y preguntas frecuentes para el equipo.

Selecciona un documento del índice de la izquierda para verlo. Los documentos se
sirven desde el directorio `kb/` de la plataforma.

> Consejo: puedes enlazar directamente a un documento con `?doc=<nombre>.md`.
