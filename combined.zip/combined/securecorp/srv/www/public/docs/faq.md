# Preguntas frecuentes

**¿Cómo accedo al portal de empleados?**
Tu sesión te asigna un rol automáticamente. Solo los administradores ven el
secreto corporativo.

**¿Para qué sirve el compositor de alertas?**
Permite plantillas con etiquetas de fusión como `[name]` para personalizar los
avisos de estado a tus clientes.

**¿Y el desbloqueo de administración?**
Requiere la clave de mantenimiento que custodia el equipo de operaciones.
