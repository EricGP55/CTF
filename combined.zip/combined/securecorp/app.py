#!/usr/bin/env python3
"""
SecureCorp — a single themed "cloud security platform" that bundles FOUR
independent web challenges, Juice-Shop style. Each module looks like a real
product feature and yields its own flag:

  1. Portal de empleados        -> Cookie tampering   (set role=admin)
  2. Centro de documentación    -> LFI / path traversal (read internal file)
  3. Compositor de alertas      -> SSTI with WAF bypass (Jinja2)
  4. Desbloqueo de admin        -> password hidden in the HTML source

Everything shares one brand, one stylesheet and one navigation bar, so the
challenges blend together as if they were genuine features of the SaaS.
"""
import os

from flask import Flask, request, make_response, render_template_string

app = Flask(__name__)
BASE = os.path.dirname(os.path.abspath(__file__))

# --------------------------------------------------------------- secrets ----
# NOTHING secret is hard-coded. Real flags/password are injected at deploy time
# via environment variables (set them in the Render dashboard, never in git).
# The defaults below are obvious placeholders so the app still runs locally.
#
#   FLAG_COOKIE      -> shown when the role cookie is tampered to 'admin'
#   FLAG_UNLOCK      -> shown when the hidden maintenance password is submitted
#   HIDDEN_PASSWORD  -> maintenance password, rendered (invisibly) in the HTML
#   FLAG_SSTI        -> written into flag.txt (read via the SSTI payload)
#   FLAG_LFI         -> written into srv/private/flag.txt (read via path traversal)
SSTI_FILE = os.path.join(BASE, "flag.txt")
LFI_FILE = os.path.join(BASE, "srv", "private", "flag.txt")
BOOT_SECRETS = os.path.join(BASE, ".boot_secrets")


def _load_memory_secrets():
    """Load the in-memory-only secrets (cookie/unlock/password).

    In production, entrypoint.sh drops them in .boot_secrets and launches python
    with a *scrubbed* environment (so /proc/self/environ can't leak anything).
    We read that file once and delete it immediately, so these three secrets
    never sit in a file an LFI could read, nor in the process environment.

    For plain local dev (`python app.py`) we fall back to os.environ, then to
    obvious placeholders.
    """
    vals = {}
    if os.path.exists(BOOT_SECRETS):
        try:
            with open(BOOT_SECRETS, encoding="utf-8") as f:
                for line in f:
                    if "=" in line:
                        k, v = line.rstrip("\n").split("=", 1)
                        vals[k] = v
        finally:
            try:
                os.remove(BOOT_SECRETS)   # scrub from disk right away
            except OSError:
                pass

    def get(key, default):
        return vals.get(key) or os.environ.get(key) or default

    return (
        get("FLAG_COOKIE", "flag{PLACEHOLDER_set_FLAG_COOKIE}"),
        get("FLAG_UNLOCK", "flag{PLACEHOLDER_set_FLAG_UNLOCK}"),
        get("HIDDEN_PASSWORD", "changeme-set-HIDDEN_PASSWORD"),
    )


def _init_file_flags_from_env():
    """Local-dev convenience: if FLAG_SSTI/FLAG_LFI are in the env (i.e. you ran
    `python app.py` directly), materialise the file-based flags. In Docker this
    is already done by entrypoint.sh before python starts."""
    ssti = os.environ.get("FLAG_SSTI")
    if ssti:
        with open(SSTI_FILE, "w", encoding="utf-8") as f:
            f.write(ssti.strip() + "\n")
    lfi = os.environ.get("FLAG_LFI")
    if lfi:
        os.makedirs(os.path.dirname(LFI_FILE), exist_ok=True)
        with open(LFI_FILE, "w", encoding="utf-8") as f:
            f.write("SecureCorp — almacenamiento privado (NO DISTRIBUIR)\n\n"
                    + lfi.strip() + "\n")


_init_file_flags_from_env()
FLAG_COOKIE, FLAG_UNLOCK, HIDDEN_PASSWORD = _load_memory_secrets()

# ------------------------------------------------------------ SSTI WAF -------
BLOCKED = [
    "import", "eval", "exec", "system", "popen", "subprocess",
    "os", "sys", "commands", "check_output", "getattr",
    "subclasses", "mro", "base", "class", "config",
]
MERGE_TAGS = {"[name]": "{{ name }}", "[occasion]": "{{ occasion }}",
              "[sender]": "{{ sender }}"}


def ssti_blocked(payload: str) -> bool:
    if "_" in payload:
        return True
    low = payload.lower()
    return any(bad in low for bad in BLOCKED)


def apply_merge_tags(text: str) -> str:
    for tag, repl in MERGE_TAGS.items():
        text = text.replace(tag, repl)
    return text


# ------------------------------------------------------------- styles -------
BASE_CSS = """
  :root{
    --bg:#0b1020; --bg2:#0e1430; --card:#121a36; --card2:#0f1730;
    --text:#e7ecff; --muted:#9aa6c7; --line:rgba(255,255,255,.08);
    --brand:#6c8bff; --brand2:#36e6c0; --accent:#ff7ab6;
    --ok:#2ee6a6; --warn:#ffce6b; --shadow:0 20px 60px rgba(0,0,0,.45);
  }
  *{box-sizing:border-box}
  html{scroll-behavior:smooth}
  body{margin:0;font-family:'Inter',system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
    color:var(--text);line-height:1.6;
    background:
      radial-gradient(1200px 600px at 80% -10%, rgba(108,139,255,.25), transparent 60%),
      radial-gradient(900px 500px at -10% 10%, rgba(54,230,192,.18), transparent 55%),
      var(--bg);}
  a{color:inherit;text-decoration:none}
  .container{max-width:1080px;margin:0 auto;padding:0 24px}
  .pill{display:inline-flex;align-items:center;gap:8px;padding:6px 14px;border-radius:999px;
    font-size:13px;font-weight:600;border:1px solid var(--line);background:rgba(255,255,255,.04)}
  .dot{width:8px;height:8px;border-radius:50%;background:var(--brand2);box-shadow:0 0 12px var(--brand2)}
  .btn{display:inline-flex;align-items:center;gap:8px;padding:12px 22px;border-radius:12px;
    font-weight:700;font-size:15px;cursor:pointer;border:1px solid transparent;transition:.2s}
  .btn-primary{background:linear-gradient(120deg,var(--brand),var(--brand2));color:#06122b;
    box-shadow:0 10px 30px rgba(108,139,255,.35)}
  .btn-primary:hover{transform:translateY(-2px)}
  .btn-ghost{background:rgba(255,255,255,.04);border-color:var(--line);color:var(--text)}
  .btn-ghost:hover{background:rgba(255,255,255,.09)}
  header.nav{position:sticky;top:0;z-index:50;backdrop-filter:blur(14px);
    background:rgba(11,16,32,.6);border-bottom:1px solid var(--line)}
  .nav-inner{display:flex;align-items:center;justify-content:space-between;height:68px}
  .brand{display:flex;align-items:center;gap:12px;font-weight:800;letter-spacing:.3px}
  .logo{width:34px;height:34px;border-radius:10px;display:grid;place-items:center;
    background:linear-gradient(135deg,var(--brand),var(--brand2));color:#06122b;font-weight:900}
  nav.links{display:flex;gap:24px;font-size:15px;color:var(--muted);font-weight:600}
  nav.links a:hover{color:var(--text)}
  @media(max-width:880px){nav.links{display:none}}
  .hero{padding:84px 0 50px;text-align:center}
  .hero h1{font-size:clamp(34px,6vw,58px);line-height:1.05;margin:18px 0 16px;font-weight:900;letter-spacing:-1px}
  .hero h1 span{background:linear-gradient(120deg,var(--brand),var(--brand2),var(--accent));
    -webkit-background-clip:text;background-clip:text;color:transparent}
  .hero p.lead{color:var(--muted);font-size:19px;max-width:620px;margin:0 auto 30px}
  .cta{display:flex;gap:14px;justify-content:center;flex-wrap:wrap}
  section{padding:60px 0}
  .eyebrow{color:var(--brand2);font-weight:700;letter-spacing:2px;font-size:13px;text-transform:uppercase}
  h2.title{font-size:clamp(24px,4vw,38px);font-weight:850;margin:8px 0 12px;letter-spacing:-.5px}
  .sub{color:var(--muted);max-width:620px}
  .grid{display:grid;gap:20px;margin-top:34px}
  .g3{grid-template-columns:repeat(3,1fr)}.g2{grid-template-columns:1.1fr .9fr}
  @media(max-width:820px){.g3,.g2{grid-template-columns:1fr}}
  .card{background:linear-gradient(180deg,var(--card),var(--card2));border:1px solid var(--line);
    border-radius:18px;padding:26px;box-shadow:var(--shadow);transition:.25s}
  .card:hover{transform:translateY(-3px);border-color:rgba(108,139,255,.35)}
  .ic{width:46px;height:46px;border-radius:12px;display:grid;place-items:center;font-size:22px;
    background:rgba(108,139,255,.14);border:1px solid var(--line);margin-bottom:16px}
  .card h3{margin:0 0 8px;font-size:19px}.card p{margin:0;color:var(--muted);font-size:15px}
  .stats{display:flex;gap:40px;justify-content:center;flex-wrap:wrap;margin-top:10px}
  .stat b{display:block;font-size:32px;font-weight:900;
    background:linear-gradient(120deg,var(--brand),var(--brand2));-webkit-background-clip:text;background-clip:text;color:transparent}
  .stat span{color:var(--muted);font-size:14px}
  label{display:block;font-size:12px;font-weight:700;color:#aab4d6;margin:14px 0 6px;text-transform:uppercase;letter-spacing:.5px}
  input,select,textarea{width:100%;font-family:inherit;font-size:14px;padding:11px 13px;border-radius:11px;
    border:1px solid var(--line);background:rgba(255,255,255,.03);color:var(--text)}
  textarea{height:110px;resize:vertical;font-family:'JetBrains Mono',ui-monospace,monospace;line-height:1.5}
  .tags{display:flex;flex-wrap:wrap;gap:7px;margin-top:9px}
  .tag{font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--brand2);background:rgba(54,230,192,.08);
    border:1px solid rgba(54,230,192,.2);padding:4px 9px;border-radius:7px}
  .badge{display:inline-flex;align-items:center;gap:8px;padding:6px 14px;border-radius:999px;font-size:13px;font-weight:700}
  .b-guest{background:rgba(255,255,255,.06);color:var(--muted);border:1px solid var(--line)}
  .b-admin{background:rgba(46,230,166,.14);color:var(--ok);border:1px solid rgba(46,230,166,.4)}
  .portal-head{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap}
  .locked{margin-top:22px;display:flex;gap:16px;align-items:flex-start;padding:20px;border-radius:14px;
    background:rgba(255,122,182,.06);border:1px solid rgba(255,122,182,.25)}
  .locked .ic{margin:0;background:rgba(255,122,182,.12)}
  .flag-box{margin-top:22px;padding:24px;border-radius:14px;text-align:center;
    background:radial-gradient(400px 200px at 50% 0,rgba(46,230,166,.18),transparent),rgba(46,230,166,.05);
    border:1px solid rgba(46,230,166,.4)}
  .flag-box code{display:inline-block;margin-top:10px;font-size:18px;font-weight:800;color:var(--ok);
    letter-spacing:.4px;font-family:'JetBrains Mono',ui-monospace,monospace;word-break:break-all}
  .notice{margin-top:14px;font-size:13px;padding:11px 13px;border-radius:10px;
    background:rgba(255,206,107,.08);border:1px solid rgba(255,206,107,.3);color:var(--warn)}
  .preview{border-radius:14px;padding:24px;min-height:120px;color:#06122b;font-weight:600;
    background:linear-gradient(150deg,#6c8bff,#ff7ab6);margin-top:6px;white-space:pre-wrap}
  .doc-layout{display:grid;grid-template-columns:230px 1fr;gap:18px;margin-top:8px}
  @media(max-width:760px){.doc-layout{grid-template-columns:1fr}}
  .doc-index a{display:block;padding:10px 12px;border-radius:10px;color:var(--muted);font-weight:600;font-size:14px}
  .doc-index a:hover{background:rgba(255,255,255,.05);color:var(--text)}
  pre.doc{background:#070b18;border:1px solid var(--line);border-radius:12px;padding:18px;overflow:auto;
    font-family:'JetBrains Mono',ui-monospace,monospace;font-size:13px;color:#cdd6ff;white-space:pre-wrap;word-break:break-word;max-height:360px}
  .url-hint{font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--muted);margin-top:8px}
  footer{border-top:1px solid var(--line);padding:40px 0;margin-top:30px;color:var(--muted)}
  .foot-inner{display:flex;justify-content:space-between;align-items:center;gap:18px;flex-wrap:wrap}
  .legal{max-width:1080px;margin:22px auto 0;padding:0 24px;font-size:11px;color:#11183300;line-height:1.5}
"""

# ------------------------------------------------------------- page ----------
PAGE = """<!doctype html>
<html lang="es"><head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SecureCorp — Plataforma de seguridad en la nube</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
  <style>{{ css }}</style>
</head>
<body id="top">

  <header class="nav"><div class="container nav-inner">
    <a class="brand" href="#top"><span class="logo">S</span> SecureCorp</a>
    <nav class="links">
      <a href="#portal">Portal</a>
      <a href="#vault">Documentación</a>
      <a href="#alerts">Alertas</a>
      <a href="#unlock">Administración</a>
    </nav>
    <a class="btn btn-ghost" href="#portal">Acceder &rarr;</a>
  </div></header>

  <main>
    <div class="container hero">
      <span class="pill"><span class="dot"></span> Confianza cero · cifrado de extremo a extremo</span>
      <h1>Una plataforma.<br><span>Toda tu seguridad.</span></h1>
      <p class="lead">SecureCorp unifica identidad, documentación, alertas y administración
        de secretos en un solo lugar. Despliega en minutos.</p>
      <div class="cta">
        <a class="btn btn-primary" href="#portal">Entrar al portal</a>
        <a class="btn btn-ghost" href="#vault">Explorar la suite</a>
      </div>
      <div class="stats" style="margin-top:46px">
        <div class="stat"><b>12K+</b><span>empresas</span></div>
        <div class="stat"><b>99.99%</b><span>uptime</span></div>
        <div class="stat"><b>4.9/5</b><span>satisfacción</span></div>
        <div class="stat"><b>0</b><span>brechas en 2025</span></div>
      </div>
    </div>

    <!-- ================= MÓDULO 1 · PORTAL (cookie) ================= -->
    <section id="portal" class="container">
      <span class="eyebrow">Identidad</span>
      <h2 class="title">Portal de empleados</h2>
      <p class="sub">Zona reservada. El secreto corporativo solo es visible para administradores.</p>
      <div class="card" style="margin-top:30px">
        <div class="portal-head">
          <div><h3 style="margin:0;font-size:21px">Panel de control</h3>
            <p style="margin:4px 0 0;color:var(--muted)">Sesión iniciada en el portal</p></div>
          {% if role == 'admin' %}<span class="badge b-admin">&#9679; Rol: administrador</span>
          {% else %}<span class="badge b-guest">&#9679; Rol: {{ role }}</span>{% endif %}
        </div>
        {% if role == 'admin' %}
          <div class="flag-box"><div style="font-size:28px">&#128273;</div>
            <p style="margin:8px 0 0;color:var(--muted)">Acceso concedido al secreto corporativo:</p>
            <code>{{ flag_cookie }}</code></div>
        {% else %}
          <div class="locked"><div class="ic">&#128274;</div><div>
            <h3 style="margin:0 0 6px">Acceso restringido</h3>
            <p style="margin:0">Solo cuentas con rol <code>admin</code>. Navegas como
              <b>{{ role }}</b>. Tu rol se conserva entre visitas gracias a tu sesión.</p>
          </div></div>
        {% endif %}
      </div>
    </section>

    <!-- ================= MÓDULO 2 · DOCUMENTACIÓN (LFI) ================= -->
    <section id="vault" class="container">
      <span class="eyebrow">Conocimiento</span>
      <h2 class="title">Centro de documentación</h2>
      <p class="sub">Guías y políticas servidas desde el repositorio público <code>kb/</code>.</p>
      <div class="card" style="margin-top:30px">
        <div class="doc-layout">
          <div class="doc-index">
            <a href="?doc=welcome.md#vault">📄 Bienvenida</a>
            <a href="?doc=security-policy.md#vault">📄 Política de seguridad</a>
            <a href="?doc=faq.md#vault">📄 Preguntas frecuentes</a>
          </div>
          <div>
            {% if lfi_content is not none %}
              <p class="url-hint">GET /?doc={{ lfi_doc }}</p>
              <pre class="doc">{{ lfi_content }}</pre>
            {% else %}
              <p style="color:var(--muted);margin-top:6px">Selecciona un documento del índice
                para visualizarlo. La ruta del documento viaja en el parámetro
                <code>doc</code> de la URL.</p>
            {% endif %}
          </div>
        </div>
      </div>
    </section>

    <!-- ================= MÓDULO 3 · ALERTAS (SSTI) ================= -->
    <section id="alerts" class="container">
      <span class="eyebrow">Comunicación</span>
      <h2 class="title">Compositor de alertas</h2>
      <p class="sub">Diseña avisos de estado para tus clientes. Usa etiquetas de fusión
        y la plataforma rellena los datos al enviar.</p>
      <div class="grid g2" style="margin-top:30px">
        <form class="card" method="post" action="/#alerts" autocomplete="off">
          <h3 style="margin:0 0 4px;font-size:19px">Plantilla del aviso</h3>
          <p style="margin:0;color:var(--muted);font-size:14px">Etiquetas disponibles abajo.</p>
          <label for="msg">Mensaje</label>
          <textarea id="msg" name="msg" placeholder="Hola [name], tu servicio está operativo de nuevo. — [sender]">{{ ssti_raw }}</textarea>
          <div class="tags"><span class="tag">[name]</span><span class="tag">[occasion]</span><span class="tag">[sender]</span></div>
          <button class="btn btn-primary" style="margin-top:16px">Generar vista previa</button>
          {% if ssti_notice %}<div class="notice">{{ ssti_notice }}</div>{% endif %}
        </form>
        <div class="card">
          <h3 style="margin:0 0 10px;font-size:19px">Vista previa</h3>
          <div class="preview">{% if ssti_rendered is not none %}{{ ssti_rendered|safe }}{% else %}Tu aviso aparecerá aquí. ✨{% endif %}</div>
          <p style="color:var(--muted);font-size:12px;margin-top:10px">La vista previa usa datos de muestra.</p>
        </div>
      </div>
    </section>

    <!-- ================= MÓDULO 4 · ADMIN (hidden password) ================= -->
    <section id="unlock" class="container">
      <span class="eyebrow">Operaciones</span>
      <h2 class="title">Desbloqueo de administración</h2>
      <p class="sub">El modo mantenimiento requiere la clave que custodia el equipo de operaciones.</p>
      <div class="card" style="margin-top:30px;max-width:520px">
        <form method="post" action="/#unlock" autocomplete="off">
          <label for="pw">Clave de mantenimiento</label>
          <input id="pw" name="pw" type="text" placeholder="••••••••••••" value="">
          <button class="btn btn-primary" style="margin-top:16px">Desbloquear</button>
        </form>
        {% if unlock_result == 'ok' %}
          <div class="flag-box"><div style="font-size:28px">&#9989;</div>
            <p style="margin:8px 0 0;color:var(--muted)">Modo mantenimiento activado:</p>
            <code>{{ flag_unlock }}</code></div>
        {% elif unlock_result == 'bad' %}
          <div class="notice">Clave incorrecta. El modo mantenimiento sigue bloqueado.</div>
        {% endif %}
      </div>
    </section>
  </main>

  <footer><div class="container foot-inner">
    <div class="brand"><span class="logo">S</span> SecureCorp</div>
    <div>&copy; 2026 SecureCorp Inc. · Todos los derechos reservados</div>
    <div style="display:flex;gap:18px"><a href="#">Privacidad</a><a href="#">Términos</a><a href="#">Estado</a></div>
  </div>
  <p class="legal">SecureCorp Inc. opera bajo licencia ISO 27001. Este software se distribuye &laquo;tal cual&raquo;, sin garant&iacute;as de ning&uacute;n tipo. El uso de esta plataforma implica la aceptaci&oacute;n de los t&eacute;rminos de servicio. Build a3f9c. Internal note for ops: maintenance key = {{ hidden_pw }} — do not ship to prod. Todos los nombres de producto son marcas registradas de sus respectivos propietarios. La reproducci&oacute;n total o parcial sin autorizaci&oacute;n expresa queda prohibida.</p>
  </footer>
</body></html>"""


def render_page(**over):
    role = request.cookies.get("role") or "guest"
    ctx = dict(
        css=BASE_CSS, role=role,
        flag_cookie=FLAG_COOKIE if role == "admin" else None,
        flag_unlock=FLAG_UNLOCK, hidden_pw=HIDDEN_PASSWORD,
        lfi_doc=None, lfi_content=None,
        ssti_raw="", ssti_rendered=None, ssti_notice=None,
        unlock_result=None,
    )
    ctx.update(over)
    body = render_template_string(PAGE, **ctx)
    resp = make_response(body)
    if request.cookies.get("role") is None:
        # Editable from the browser (no HttpOnly) -> cookie tampering.
        resp.set_cookie("role", "guest")
    return resp


# Docs are served from a deeply nested public directory, so reaching anything
# sensitive requires climbing several levels with ../ (path traversal).
DOCS_DIR = os.path.join(BASE, "srv", "www", "public", "docs")


def read_doc(doc):
    """Serve a doc from the public docs dir. Vulnerable: no path sanitisation."""
    path = os.path.join(DOCS_DIR, doc)
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception:
        return "[error] No se pudo abrir el documento solicitado."


@app.route("/", methods=["GET", "POST"])
def index():
    over = {}

    # --- LFI module (query param) ---
    doc = request.args.get("doc")
    if doc:
        over["lfi_doc"] = doc
        over["lfi_content"] = read_doc(doc)

    if request.method == "POST":
        # --- SSTI module ---
        if "msg" in request.form:
            raw = request.form.get("msg", "")
            over["ssti_raw"] = raw
            if raw.strip():
                if ssti_blocked(raw):
                    over["ssti_notice"] = ("No pudimos renderizar ese mensaje. Algunos "
                                           "caracteres no son compatibles con las fuentes "
                                           "de la tarjeta; prueba a simplificarlo.")
                else:
                    try:
                        tmpl = apply_merge_tags(raw)
                        over["ssti_rendered"] = render_template_string(
                            tmpl, name="friend", occasion="incidencia",
                            sender="Equipo SecureCorp")
                    except Exception:
                        over["ssti_notice"] = "No pudimos renderizar ese mensaje. Revisa tus etiquetas."

        # --- Hidden-password module ---
        if "pw" in request.form:
            pw = request.form.get("pw", "")
            over["unlock_result"] = "ok" if pw == HIDDEN_PASSWORD else ("bad" if pw else None)

    return render_page(**over)


if __name__ == "__main__":
    # Render (and most PaaS) provide the listening port via $PORT.
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)
