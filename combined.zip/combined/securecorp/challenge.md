# SecureCorp — Suite de 4 retos en una sola web

- **Categoría:** Web (multi-reto, estilo OWASP Juice Shop)
- **Tema:** Una única plataforma SaaS de seguridad con 4 módulos. Cada módulo es
  un reto independiente con **su propia flag** (formato `flag{...}`).

## Enunciado

*SecureCorp* es una plataforma de seguridad en la nube con cuatro módulos. Cada
uno esconde una flag distinta. La estética y la navegación son las mismas en toda
la web: los retos están mezclados como si fueran funciones reales del producto.
Encuéntralas todas.

| # | Módulo | Sección | Vulnerabilidad |
|---|--------|---------|----------------|
| 1 | Portal de empleados | `#portal` | Manipulación de cookies |
| 2 | Centro de documentación | `#vault` | LFI / Path Traversal |
| 3 | Compositor de alertas | `#alerts` | SSTI (Jinja2) con bypass de WAF |
| 4 | Desbloqueo de administración | `#unlock` | Contraseña oculta en el HTML |

## Pistas por módulo

### 1. Portal de empleados (cookies)
> El portal recuerda quién eres entre visitas. ¿Dónde guarda tu navegador ese
> "quién eres" y quién decide su valor?

### 2. Centro de documentación (LFI)
> Los documentos se sirven por nombre desde un directorio público **muy anidado**.
> El nombre viaja en la URL sin que nadie lo valide. Tendrás que subir **varios
> `../`** para salir de ahí; hay ficheros internos fuera del árbol público.

### 3. Compositor de alertas (SSTI)
> Anuncia etiquetas con corchetes `[name]`, pero el motor entiende más sintaxis.
> Confírmalo, choca con el filtro silencioso, y recuerda: un carácter prohibido
> puede escribirse de otra forma dentro de una cadena, y un *filtro* de Jinja
> alcanza atributos sin escribir el punto.

### 4. Desbloqueo de administración (oculto en el HTML)
> La clave de mantenimiento no se ve en pantalla... pero está en la página.
> No está en un comentario. Mira el código fuente (o selecciona todo el texto).

## Objetivo

Conseguir las **4 flags**.
