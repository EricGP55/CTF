#!/bin/sh
# Materialise secrets from the environment, then launch the app with a SCRUBBED
# environment so /proc/self/environ (readable via the LFI challenge) leaks nothing.
set -eu

# File-based flags: these ARE the intended read targets for the LFI/SSTI
# challenges, so they must persist on disk.
if [ -n "${FLAG_SSTI:-}" ]; then
  printf '%s\n' "$FLAG_SSTI" > /app/flag.txt
fi
if [ -n "${FLAG_LFI:-}" ]; then
  mkdir -p /app/srv/private
  printf 'SecureCorp — almacenamiento privado (NO DISTRIBUIR)\n\n%s\n' "$FLAG_LFI" \
    > /app/srv/private/flag.txt
fi

# In-memory-only secrets (cookie / unlock / hidden password): hand them to the
# app through a boot file it reads and deletes on startup. Never in an
# LFI-readable file at request time, never in the process environment.
printf 'FLAG_COOKIE=%s\nFLAG_UNLOCK=%s\nHIDDEN_PASSWORD=%s\n' \
  "${FLAG_COOKIE:-}" "${FLAG_UNLOCK:-}" "${HIDDEN_PASSWORD:-}" > /app/.boot_secrets

# Exec python WITHOUT the secrets in its environment -> /proc/self/environ clean.
exec env -u FLAG_COOKIE -u FLAG_UNLOCK -u HIDDEN_PASSWORD -u FLAG_SSTI -u FLAG_LFI \
  python app.py
